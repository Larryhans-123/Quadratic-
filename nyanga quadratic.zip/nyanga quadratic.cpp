#include <iostream>
#include <cmath>
using namespace std;
// Function to calculate the roots
void quadraticRoots(double a, double b, double c)
{
    if (a == 0)
  {
    cout<<"this is not a quadratic equation."<< endl;
    if (b!=0)
    cout<<"it is a linear equation."<< endl;
    else
    cout<<"it has no solution."<<endl;
    return;
  }
  double D=b*b-4*a*c;
  cout <<"Discriminant="<<D<< endl;
  if (D>0)
  {
  	double x1 =(-b +sqrt(D))/(2*a);
  	double x2=(-b - sqrt(D))/(2*a);
  	cout<<"two real and distict roots."<<endl;
  	cout<<"root 1 ="<< x1 <<endl;
  	cout<<"root 2= "<< x2 <<endl;
  }
  else
  {
  	double realpart = -b/ (2*a);
  	double imaginarypart = sqrt(-D) / abs(2*a);
  	cout<<"two complex roots."<<endl;
  	cout<<"root 1="<< realpart <<"+"
  	<<imaginarypart<< "i" <<endl;
  	cout <<"root 2="<<realpart<< "-"
  	<<imaginarypart<<"i" << endl;
  }
}
int main()
{
double a,b,c;
cout <<"Enter the values of a, b and c:";
cin >>a >>b >>c;
quadraticRoots(a, b, c);
return 0;
}

